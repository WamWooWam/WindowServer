'use strict';

var user32 = require('user32');
var gdi32 = require('gdi32');
var kernel32 = require('kernel32');

const Globals = {
    hInstance: 0,
    hMainWnd: 0,
    hFindReplaceDlg: 0,
    hEdit: 0,
    hStatusBar: 0,
    hFont: 0,
    hMenu: 0,
    lfFont: null,
    bWrapLongLines: false,
    bShowStatusBar: false,
    szFindText: null,
    szReplaceText: null,
    szFileName: null,
    szFileTitle: null,
    szFilter: null,
    lMargins: {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0,
    },
    szHeader: null,
    szFooter: null,
    szStatusBarLineCol: null,
    encFile: 0,
    iEoln: 0,
    find: null,
    editProc: null,
    mainRect: {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0,
    },
    bWasModified: false,
};

function InitData(hInstance) {
}
async function LoadSettingsFromRegistry() {
    let cxScreen = user32.GetSystemMetrics(user32.SM.CXSCREEN), cyScreen = user32.GetSystemMetrics(user32.SM.CYSCREEN);
    let dwPointSize = 10;
    Globals.bShowStatusBar = true;
    Globals.bWrapLongLines = false;
    gdi32.SetRect(Globals.lMargins, 750, 1000, 750, 1000);
    Globals.lfFont = {
        lfCharSet: gdi32.DEFAULT_CHARSET,
        lfWeight: gdi32.FW.NORMAL,
    };
    Globals.mainRect.left = user32.CW_USEDEFAULT;
    Globals.mainRect.top = user32.CW_USEDEFAULT;
    let cx = Math.min(cxScreen * 3 / 4, 640);
    let cy = Math.min(cyScreen * 3 / 4, 480);
    // RegOpenKeyEx(HKEY_CURRENT_USER, s_szRegistryKey, 0, KEY_QUERY_VALUE, &hKey);
    // if (hKey)
    // {
    //     TODO: read settings from registry
    //     RegCloseKey(hKey);
    // }
    let dc = await user32.GetDC(0);
    Globals.lfFont.lfHeight = kernel32.MulDiv(dwPointSize, await gdi32.GetDeviceCaps(dc, gdi32.LOGPIXELSY), 72);
    Globals.mainRect.right = Globals.mainRect.left + cx;
    Globals.mainRect.bottom = Globals.mainRect.top + cy;
    Globals.lfFont.lfFaceName = "Courier New";
    Globals.szHeader = "&f";
    Globals.szFooter = "Page &p";
    let hFont = await gdi32.CreateFontIndirect(Globals.lfFont);
    await user32.SendMessage(Globals.hEdit, user32.WM.SETFONT, hFont, 1);
    if (hFont) {
        if (Globals.hFont)
            await gdi32.DeleteObject(Globals.hFont);
        Globals.hFont = hFont;
    }
}

async function WndProc(hWnd, msg, wParam, lParam) {
    switch (msg) {
        case user32.WM.CREATE: {
            break;
        }
        default: {
            return await user32.DefWindowProc(hWnd, msg, wParam, lParam);
        }
    }
    return 0;
}
async function WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow) {
    const className = "Notepad";
    const winName = "Notepad";
    await InitData();
    await LoadSettingsFromRegistry();
    const wndClass = {
        lpfnWndProc: WndProc,
        hInstance: Globals.hInstance,
        hIcon: await user32.LoadIcon(hInstance, "IDI_NOTEPAD"),
        hCursor: await user32.LoadCursor(0, user32.MAKEINTRESOURCE(user32.IDC.ARROW)),
        hbrBackground: user32.COLOR.WINDOW + 1,
        lpszMenuName: "IDR_MENU",
        lpszClassName: className,
        hIconSm: await user32.LoadImage(hInstance, "IDI_NOTEPAD", user32.IMAGE.ICON, user32.GetSystemMetrics(user32.SM.CXSMICON), user32.GetSystemMetrics(user32.SM.CYSMICON), 0),
        cbClsExtra: 0,
        cbWndExtra: 0,
        cbSize: 0,
        style: 0,
    };
    if (!user32.RegisterClass(wndClass)) {
        return 1;
    }
    let hMonitor = await user32.MonitorFromRect(Globals.mainRect, user32.MONITOR.DEFAULTTOPRIMARY);
    let mi = await user32.GetMonitorInfo(hMonitor);
    if (!mi) {
        return 1;
    }
    let x = Globals.mainRect.top;
    let y = Globals.mainRect.left;
    let rcIntersect = {};
    if (!gdi32.IntersectRect(rcIntersect, Globals.mainRect, mi.rcWork)) {
        x = user32.CW_USEDEFAULT;
        y = user32.CW_USEDEFAULT;
    }
    let hWnd = await user32.CreateWindow(className, winName, user32.WS.OVERLAPPEDWINDOW, x, y, Globals.mainRect.right - Globals.mainRect.left, Globals.mainRect.bottom - Globals.mainRect.top, 0, 0, hInstance, 0);
    if (!hWnd) {
        return 1;
    }
    await user32.ShowWindow(hWnd, user32.SW.SHOWDEFAULT);
    // load accelerator table
    let msg = {};
    while (await user32.GetMessage(msg, 0, 0, 0)) {
        await user32.TranslateMessage(msg);
        await user32.DispatchMessage(msg);
    }
    return msg.wParam;
}
async function main() {
    return WinMain(await kernel32.GetModuleHandle(null));
}

exports.WinMain = WinMain;
exports.main = main;
//# sourceMappingURL=notepad.js.map
