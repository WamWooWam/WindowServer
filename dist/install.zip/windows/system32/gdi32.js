'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var ntdll = require('ntdll');

exports.RGN = void 0;
(function (RGN) {
    RGN[RGN["AND"] = 1] = "AND";
    RGN[RGN["OR"] = 2] = "OR";
    RGN[RGN["XOR"] = 3] = "XOR";
    RGN[RGN["DIFF"] = 4] = "DIFF";
    RGN[RGN["COPY"] = 5] = "COPY";
})(exports.RGN || (exports.RGN = {}));
exports.PS = void 0;
(function (PS) {
    PS[PS["SOLID"] = 0] = "SOLID";
    PS[PS["DASH"] = 1] = "DASH";
    PS[PS["DOT"] = 2] = "DOT";
    PS[PS["DASHDOT"] = 3] = "DASHDOT";
    PS[PS["DASHDOTDOT"] = 4] = "DASHDOTDOT";
    PS[PS["NULL"] = 5] = "NULL";
    PS[PS["INSIDEFRAME"] = 6] = "INSIDEFRAME";
})(exports.PS || (exports.PS = {}));
const WHITE_BRUSH = 0;
const LTGRAY_BRUSH = 1;
const GRAY_BRUSH = 2;
const DKGRAY_BRUSH = 3;
const BLACK_BRUSH = 4;
const NULL_BRUSH = 5;
const HOLLOW_BRUSH = NULL_BRUSH;
const WHITE_PEN = 6;
const BLACK_PEN = 7;
const NULL_PEN = 8;
const OEM_FIXED_FONT = 10;
const ANSI_FIXED_FONT = 11;
const ANSI_VAR_FONT = 12;
const SYSTEM_FONT = 13;
const DEVICE_DEFAULT_FONT = 14;
const DEFAULT_PALETTE = 15;
const SYSTEM_FIXED_FONT = 16;
const DEFAULT_GUI_FONT = 17;
const DC_BRUSH = 18;
const DC_PEN = 19;
exports.BS = void 0;
(function (BS) {
    BS[BS["SOLID"] = 0] = "SOLID";
    BS[BS["NULL"] = 1] = "NULL";
    BS[BS["HATCHED"] = 2] = "HATCHED";
    BS[BS["PATTERN"] = 3] = "PATTERN";
    BS[BS["DIBPATTERN"] = 5] = "DIBPATTERN";
    BS[BS["DIBPATTERNPT"] = 6] = "DIBPATTERNPT";
    BS[BS["PATTERN8X8"] = 7] = "PATTERN8X8";
    BS[BS["DIBPATTERN8X8"] = 8] = "DIBPATTERN8X8";
})(exports.BS || (exports.BS = {}));
exports.HS = void 0;
(function (HS) {
    HS[HS["HORIZONTAL"] = 0] = "HORIZONTAL";
    HS[HS["VERTICAL"] = 1] = "VERTICAL";
    HS[HS["FDIAGONAL"] = 2] = "FDIAGONAL";
    HS[HS["BDIAGONAL"] = 3] = "BDIAGONAL";
    HS[HS["CROSS"] = 4] = "CROSS";
    HS[HS["DIAGCROSS"] = 5] = "DIAGCROSS";
})(exports.HS || (exports.HS = {}));
exports.FW = void 0;
(function (FW) {
    FW[FW["DONTCARE"] = 0] = "DONTCARE";
    FW[FW["THIN"] = 100] = "THIN";
    FW[FW["EXTRALIGHT"] = 200] = "EXTRALIGHT";
    FW[FW["LIGHT"] = 300] = "LIGHT";
    FW[FW["NORMAL"] = 400] = "NORMAL";
    FW[FW["MEDIUM"] = 500] = "MEDIUM";
    FW[FW["SEMIBOLD"] = 600] = "SEMIBOLD";
    FW[FW["BOLD"] = 700] = "BOLD";
    FW[FW["EXTRABOLD"] = 800] = "EXTRABOLD";
    FW[FW["HEAVY"] = 900] = "HEAVY";
})(exports.FW || (exports.FW = {}));
const LOGPIXELSY = 90;
const LOGPIXELSX = 88;
const TRANSPARENT = 1;
const OPAQUE = 2;
const DEFAULT_CHARSET = 1;
const NONANTIALIASED_QUALITY = 3;
function InflateRect(rect, x, y) {
    rect.left -= x;
    rect.top -= y;
    rect.right += x;
    rect.bottom += y;
}
function OffsetRect(rect, x, y) {
    rect.left += x;
    rect.top += y;
    rect.right += x;
    rect.bottom += y;
}
function IntersectRect(dst, src1, src2) {
    dst.left = Math.max(src1.left, src2.left);
    dst.top = Math.max(src1.top, src2.top);
    dst.right = Math.min(src1.right, src2.right);
    dst.bottom = Math.min(src1.bottom, src2.bottom);
    return dst.left < dst.right && dst.top < dst.bottom;
}
function INRECT(x, y, rect) {
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
}
function SetRect(rect, left, top, right, bottom) {
    Object.assign(rect, { top, left, right, bottom });
}

const GDI32 = {
    CreateRectRgn: 0x00000001,
    CombineRgn: 0x00000002,
    FillRgn: 0x00000003,
    DeleteObject: 0x00000004,
    SelectObject: 0x00000005,
    CreateSolidBrush: 0x00000006,
    CreatePen: 0x00000007,
    TextOut: 0x00000008,
    SetTextColor: 0x00000009,
    Rectangle: 0x0000000A,
    GetDeviceCaps: 0x0000000B,
    CreateFontIndirect: 0x0000000C
};

const SUBSYS_GDI32 = "gdi32";

/**
 * @module gdi32
 * @description GDI Client Library
 * @see {@link https://docs.microsoft.com/en-us/windows/win32/gdi/windows-gdi}
 * @usermode
 */
// const Gdi32 = await NtRegisterSubsystem(SUBSYS_GDI32, () => { });
let Gdi32;
async function DllMain() {
    Gdi32 = await ntdll.NtRegisterSubsystem(SUBSYS_GDI32, () => { });
}
/**
 * The GetStockObject function retrieves a handle to one of the stock pens, brushes, fonts, or palettes.
 * @param nIndex The type of stock object.
 * @returns If the function succeeds, the return value is the handle to the requested logical object.
 * @see {@link https://docs.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-getstockobject}
 * @category GDI32
 * @example
 * const hBrush = await GetStockObject(WHITE_BRUSH);
 */
function GetStockObject(nIndex) {
    return 0x80000000 + nIndex;
}
/**
 * The CreateRectRgn function creates a rectangular region.
 * @param x1 The coordinates of the upper-left corner of the region in logical units.
 * @param y1 The coordinates of the upper-left corner of the region in logical units.
 * @param x2 the coordinates of the lower-right corner of the region in logical units.
 * @param y2 the coordinates of the lower-right corner of the region in logical units.
 * @returns The return value identifies the region in the calling process's region list.
 */
async function CreateRectRgn(x1, y1, x2, y2) {
    return (await Gdi32.SendMessage({
        nType: GDI32.CreateRectRgn,
        data: { x1, y1, x2, y2 }
    })).data;
}
/**
 * The CombineRgn function combines two regions and stores the result in a third region. The two regions are combined according to the specified mode.
 * @param hrgnDest A handle to a new region with dimensions defined by combining two other regions. (This region must exist before CombineRgn is called.)
 * @param hrgnSrc1 A handle to the first of two regions to be combined.
 * @param hrgnSrc2 A handle to the second of two regions to be combined.
 * @param fnCombineMode A mode indicating how the two regions will be combined.
 * @returns The return value specifies the type of the resulting region.
 */
async function CombineRgn(hrgnDest, hrgnSrc1, hrgnSrc2, fnCombineMode) {
    return (await Gdi32.SendMessage({
        nType: GDI32.CombineRgn,
        data: { hrgnDest, hrgnSrc1, hrgnSrc2, fnCombineMode }
    })).data;
}
/**
 * The FillRgn function fills a region by using the specified brush.
 * @param hDC Handle to the device context.
 * @param hrgn Handle to the region to be filled. The region's coordinates are assumed to be device coordinates.
 * @returns If the function succeeds, the return value is nonzero.
 */
async function FillRgn(hDC, hrgn) {
    return (await Gdi32.SendMessage({
        nType: GDI32.FillRgn,
        data: { hDC, hrgn }
    })).data;
}
async function DeleteObject(hObject) {
    return (await Gdi32.SendMessage({
        nType: GDI32.DeleteObject,
        data: { hObject }
    })).data;
}
async function SelectObject(hDC, hObject) {
    return (await Gdi32.SendMessage({
        nType: GDI32.SelectObject,
        data: { hDC, hObject }
    })).data;
}
async function CreateSolidBrush(crColor) {
    return (await Gdi32.SendMessage({
        nType: GDI32.CreateSolidBrush,
        data: { crColor }
    })).data;
}
async function CreatePen(iStyle, cWidth, crColor) {
    return (await Gdi32.SendMessage({
        nType: GDI32.CreatePen,
        data: { iStyle, cWidth, crColor }
    })).data;
}
async function TextOut(hDC, x, y, text) {
    return (await Gdi32.SendMessage({
        nType: GDI32.TextOut,
        data: { hDC, x, y, text }
    })).data;
}
async function SetTextColor(hDC, crColor) {
    return (await Gdi32.SendMessage({
        nType: GDI32.SetTextColor,
        data: { hDC, crColor }
    })).data;
}
async function Rectangle(hDC, left, top, right, bottom) {
    return (await Gdi32.SendMessage({
        nType: GDI32.Rectangle,
        data: { hDC, left, top, right, bottom }
    })).data;
}
async function GetDeviceCaps(hDC, nIndex) {
    return (await Gdi32.SendMessage({
        nType: GDI32.GetDeviceCaps,
        data: { hDC, nIndex }
    })).data;
}
async function CreateFontIndirect(lf) {
    return (await Gdi32.SendMessage({
        nType: GDI32.CreateFontIndirect,
        data: { lf }
    })).data;
}
const gdi32 = {
    file: "gdi32.js",
    type: "dll",
    subsystem: "console",
    arch: "js",
    entryPoint: DllMain,
    dependencies: ["ntdll.js", "kernel32.js"],
    name: "gdi32",
    version: [1, 0, 0, 0],
    rsrc: {}
};

exports.ANSI_FIXED_FONT = ANSI_FIXED_FONT;
exports.ANSI_VAR_FONT = ANSI_VAR_FONT;
exports.BLACK_BRUSH = BLACK_BRUSH;
exports.BLACK_PEN = BLACK_PEN;
exports.CombineRgn = CombineRgn;
exports.CreateFontIndirect = CreateFontIndirect;
exports.CreatePen = CreatePen;
exports.CreateRectRgn = CreateRectRgn;
exports.CreateSolidBrush = CreateSolidBrush;
exports.DC_BRUSH = DC_BRUSH;
exports.DC_PEN = DC_PEN;
exports.DEFAULT_CHARSET = DEFAULT_CHARSET;
exports.DEFAULT_GUI_FONT = DEFAULT_GUI_FONT;
exports.DEFAULT_PALETTE = DEFAULT_PALETTE;
exports.DEVICE_DEFAULT_FONT = DEVICE_DEFAULT_FONT;
exports.DKGRAY_BRUSH = DKGRAY_BRUSH;
exports.DeleteObject = DeleteObject;
exports.FillRgn = FillRgn;
exports.GRAY_BRUSH = GRAY_BRUSH;
exports.GetDeviceCaps = GetDeviceCaps;
exports.GetStockObject = GetStockObject;
exports.HOLLOW_BRUSH = HOLLOW_BRUSH;
exports.INRECT = INRECT;
exports.InflateRect = InflateRect;
exports.IntersectRect = IntersectRect;
exports.LOGPIXELSX = LOGPIXELSX;
exports.LOGPIXELSY = LOGPIXELSY;
exports.LTGRAY_BRUSH = LTGRAY_BRUSH;
exports.NONANTIALIASED_QUALITY = NONANTIALIASED_QUALITY;
exports.NULL_BRUSH = NULL_BRUSH;
exports.NULL_PEN = NULL_PEN;
exports.OEM_FIXED_FONT = OEM_FIXED_FONT;
exports.OPAQUE = OPAQUE;
exports.OffsetRect = OffsetRect;
exports.Rectangle = Rectangle;
exports.SYSTEM_FIXED_FONT = SYSTEM_FIXED_FONT;
exports.SYSTEM_FONT = SYSTEM_FONT;
exports.SelectObject = SelectObject;
exports.SetRect = SetRect;
exports.SetTextColor = SetTextColor;
exports.TRANSPARENT = TRANSPARENT;
exports.TextOut = TextOut;
exports.WHITE_BRUSH = WHITE_BRUSH;
exports.WHITE_PEN = WHITE_PEN;
exports.default = gdi32;
//# sourceMappingURL=gdi32.js.map
