'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var ntdll = require('ntdll');

const IDX_PID = 0;
const IDX_HMODULE = 1;
const IDX_LAST_ERROR = 2;
const STD_INPUT_HANDLE = -10;
const STD_OUTPUT_HANDLE = -11;
const STD_ERROR_HANDLE = -12;
const GENERIC_ALL = 0x10000000;
const GENERIC_EXECUTE = 0x20000000;
const GENERIC_WRITE = 0x40000000;
const GENERIC_READ = 0x80000000;
const CREATE_NEW = 1;
const CREATE_ALWAYS = 2;
const OPEN_EXISTING = 3;
const OPEN_ALWAYS = 4;
const TRUNCATE_EXISTING = 5;
const FILE_ATTRIBUTE_READONLY = 0x00000001;
const FILE_ATTRIBUTE_HIDDEN = 0x00000002;
const FILE_ATTRIBUTE_SYSTEM = 0x00000004;
const FILE_ATTRIBUTE_DIRECTORY = 0x00000010;
const FILE_ATTRIBUTE_ARCHIVE = 0x00000020;
const FILE_ATTRIBUTE_DEVICE = 0x00000040;
const FILE_ATTRIBUTE_NORMAL = 0x00000080;
const FILE_ATTRIBUTE_TEMPORARY = 0x00000100;
const FILE_FLAG_WRITE_THROUGH = 0x80000000;
const FILE_FLAG_OVERLAPPED = 0x40000000;
const FILE_FLAG_NO_BUFFERING = 0x20000000;
const FILE_FLAG_RANDOM_ACCESS = 0x10000000;
const FILE_FLAG_DELETE_ON_CLOSE = 0x04000000;
const FILE_SHARE_READ = 0x00000001;
const FILE_SHARE_WRITE = 0x00000002;
const FILE_SHARE_DELETE = 0x00000004;
const FILE_SHARE_VALID_FLAGS = 0x00000007;
const FILE_BEGIN = 0;
const FILE_CURRENT = 1;
const FILE_END = 2;
const FILE_GENERIC_READ = 0x80000000;
const FILE_GENERIC_WRITE = 0x40000000;
const FILE_GENERIC_EXECUTE = 0x20000000;

const KERNEL32 = {
    GetProcessInfo: 0x00000001,
    CloseHandle: 0x00000002,
    CreateFile: 0x00000003,
    ReadFile: 0x00000004,
    WriteFile: 0x00000005,
    SetFilePointer: 0x00000006,
    CreateDirectory: 0x00000007,
    GetModuleHandle: 0x00000008
};

const SUBSYS_KERNEL32 = "kernel32";

/**
 * @module kernel32
 * @description Windows NT BASE API Client Library
 * @see {@link https://docs.microsoft.com/en-us/windows/win32/api/winbase/}
 * @usermode
 */
function Kernel32_HandleMessage(msg) {
}
let Kernel32;
let K32Memory;
/**
 * Retrieves a module handle for the specified module. The module must have been loaded by the calling process.
 * @param lpModuleName The name of the loaded module (either a .dll or .exe file). If the file name extension is omitted,
 * the default library extension .dll is appended. The file name string can include a trailing point character (.) to
 * indicate that the module name has no extension. The string does not have to specify a path. When specifying a path, be
 * sure to use backslashes (\), not forward slashes (/). The name is compared (case independently) to the names of modules
 * currently mapped into the address space of the calling process.
 * @returns If the function succeeds, the return value is a handle to the specified module. If the function fails, the
 * return value is NULL. To get extended error information, call GetLastError.
 */
async function GetModuleHandle(lpModuleName) {
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.GetModuleHandle,
        data: { lpModuleName }
    });
    return msg.data.hModule;
}
/**
 * Retrieves a pseudo handle for the current process.
 * @returns The return value is a pseudo handle to the current process.
 */
function GetCurrentProcess() {
    return -1;
}
/**
 * Retrieves the calling thread's last-error code value. The last-error code is maintained on a per-thread basis. Multiple
 * threads do not overwrite each other's last-error code.
 * @returns The return value is the calling thread's last-error code.
 */
function GetLastError() {
    const lastError = Atomics.load(K32Memory, IDX_LAST_ERROR);
    return lastError;
}
/**
 * Sets the last-error code for the calling thread.
 * @param dwErrorCode The last-error code for the thread.
 */
function SetLastError(dwErrorCode) {
    console.debug(`SetLastError pid:${GetCurrentProcessId()} ${dwErrorCode}`);
    Atomics.store(K32Memory, IDX_LAST_ERROR, dwErrorCode);
}
/**
 * Retrieves the process identifier of the calling process.
 * @returns The return value is the process identifier of the calling process.
 */
function GetCurrentProcessId() {
    return Atomics.load(K32Memory, IDX_PID);
}
/**
 * Retrieves the process identifier of the specified process.
 * @param hProcess A handle to the process. The handle must have the PROCESS_QUERY_INFORMATION or PROCESS_QUERY_LIMITED_INFORMATION access right.
 * @returns If the function succeeds, the return value is a process identifier. If the function fails, the return value is zero.
 */
async function GetProcessId(hProcess) {
    if (hProcess === -1)
        return GetCurrentProcessId();
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.GetProcessInfo,
        data: { hProcess }
    });
    return msg.data.id;
}
/**
 * Creates or opens a file or I/O device. The most commonly used I/O devices are as follows: file, file stream, directory, physical disk, volume,
 * console buffer, tape drive, communications resource, mailslot, and pipe. The function returns a handle that can be used to access the file or
 * device for various types of I/O depending on the file or device and the flags and attributes specified.
 * @param lpFileName The name of the file or device to be created or opened. You may use either forward slashes (/) or backslashes (\) in this name.
 * @param dwDesiredAccess The requested access to the file or device, which can be summarized as read, write, both or neither zero).
 * @param dwShareMode The requested sharing mode of the file or device, which can be read, write, both, delete, all of these, or none (refer to the
 * following table). Access requests to attributes or extended attributes are not affected by this flag.
 * @param lpSecurityAttributes A pointer to a SECURITY_ATTRIBUTES structure that contains two separate but related data members: an optional security
 * descriptor, and a Boolean value that determines whether the returned handle can be inherited by child processes. This parameter can be NULL.
 * @param dwCreationDisposition An action to take on a file or device that exists or does not exist.
 * @param dwFlagsAndAttributes The file or device attributes and flags, FILE_ATTRIBUTE_NORMAL being the most common default value for files.
 * @param hTemplateFile A valid handle to a template file with the GENERIC_READ access right. The template file supplies file attributes and extended
 * attributes for the file that is being created. This parameter can be NULL.
 * @returns If the function succeeds, the return value is an open handle to the specified file, device, named pipe, or mail slot. If the function fails,
 * the return value is INVALID_HANDLE_VALUE. To get extended error information, call GetLastError.
 * @async
 * @category Kernel32
 * @example
 * ```ts
 * const hFile = await CreateFile("test.txt", GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
 * CloseHandle(hFile);
 * ```
 */
async function CreateFile(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile) {
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.CreateFile,
        data: {
            lpFileName,
            dwDesiredAccess,
            dwShareMode,
            lpSecurityAttributes,
            dwCreationDisposition,
            dwFlagsAndAttributes,
            hTemplateFile
        }
    });
    return msg.data.hFile;
}
/**
 * Reads data from the specified file or input/output (I/O) device. Reads occur at the position specified by the file pointer if supported by the device.
 * @param hFile A handle to the device (for example, a file, file stream, physical disk, volume, console buffer, tape drive, socket, communications resource,
 * mailslot, or pipe).
 * @param lpBuffer A pointer to the buffer that receives the data read from a file or device.
 * @param nNumberOfBytesToRead The maximum number of bytes to be read.
 * @returns If the function succeeds, the return value is nonzero (TRUE). If the function fails, or is completing asynchronously, the return value is zero
 * (FALSE). To get extended error information, call the GetLastError function.
 * @async
 * @category Kernel32
 * @example
 * ```ts
 * const hFile = await CreateFile("test.txt", GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
 * const buffer = new Uint8Array(1024);
 * const { retVal, lpNumberOfBytesRead } = await ReadFile(hFile, buffer, buffer.length);
 * CloseHandle(hFile);
 * ```
 * @see https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-readfile
 */
async function ReadFile(hFile, lpBuffer, nNumberOfBytesToRead) {
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.ReadFile,
        data: { hFile, lpBuffer, nNumberOfBytesToRead }
    });
    if (msg.data.retVal && msg.data.lpBuffer) {
        lpBuffer.set(msg.data.lpBuffer);
    }
    return { retVal: msg.data.retVal, lpNumberOfBytesRead: msg.data.lpNumberOfBytesRead };
}
/**
 * Writes data to the specified file or input/output (I/O) device.
 * @param hFile A handle to the device (for example, a file, file stream, physical disk, volume, console buffer, tape drive, socket, communications resource,
 * mailslot, or pipe).
 * @param lpBuffer A pointer to the buffer containing the data to be written to the file or device.
 * @param nNumberOfBytesToWrite The number of bytes to be written to the file or device.
 * @returns If the function succeeds, the return value is nonzero (TRUE). If the function fails, or is completing asynchronously, the return value is zero
 * (FALSE). To get extended error information, call the GetLastError function.
 * @async
 * @category Kernel32
 * @example
 * ```ts
 * const hFile = await CreateFile("test.txt", GENERIC_WRITE, 0, 0, CREATE_ALWAYS, 0, 0);
 * const buffer = new TextEncoder().encode("Hello World!");
 * const { retVal, lpNumberOfBytesWritten } = await WriteFile(hFile, buffer, buffer.length);
 * CloseHandle(hFile);
 * ```
 * @see https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-writefile
 */
async function WriteFile(hFile, lpBuffer, nNumberOfBytesToWrite) {
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.WriteFile,
        data: { hFile, lpBuffer, nNumberOfBytesToWrite }
    });
    return { retVal: msg.data.retVal, lpNumberOfBytesWritten: msg.data.lpNumberOfBytesWritten };
}
/**
 * Moves the file pointer of the specified file.
 * @param hFile A handle to the file.
 * The file handle must have been created with GENERIC_READ or GENERIC_WRITE access to the file.
 * @param lDistanceToMove The value that is added to the location specified by the dwMoveMethod parameter.
 * @param dwMoveMethod The starting point for the file pointer move.
 * @returns The return value is the new value of the file pointer, from the beginning of the file.
 * @async
 * @category Kernel32
 * @example
 * ```ts
 * const hFile = await CreateFile("test.txt", GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
 * const retVal = await SetFilePointer(hFile, 0, FILE_END);
 * CloseHandle(hFile);
 * ```
 */
async function SetFilePointer(hFile, lDistanceToMove, dwMoveMethod) {
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.SetFilePointer,
        data: { hFile, lDistanceToMove, dwMoveMethod }
    });
    return msg.data.dwNewFilePointer;
}
/**
 * Creates a new directory. If the underlying file system supports security on files and directories, the function applies a specified security descriptor
 * to the new directory.
 * @param lpPathName The path of the directory to be created. For more information, see File Names, Paths, and Namespaces.
 * @param lpSecurityAttributes A pointer to a SECURITY_ATTRIBUTES structure. The lpSecurityDescriptor member of the structure specifies a security descriptor
 * for the new directory. If lpSecurityAttributes is NULL, the directory gets a default security descriptor. The ACLs in the default security descriptor for a
 * directory are inherited from its parent directory.
 * @returns If the function succeeds, the return value is nonzero (TRUE). If the function fails, the return value is zero (FALSE). To get extended error
 */
async function CreateDirectory(lpPathName, lpSecurityAttributes) {
    const msg = await Kernel32.SendMessage({
        nType: KERNEL32.CreateDirectory,
        data: { lpPathName, lpSecurityAttributes }
    });
    return msg.data.retVal;
}
/**
 *
 * @param nStdHandle
 * @returns
 */
function GetStdHandle(nStdHandle) {
    if (nStdHandle > STD_ERROR_HANDLE && nStdHandle < STD_INPUT_HANDLE)
        return -1; // TODO: implement
    else
        return -1;
}
/**
 *
 * @param hObject
 * @returns
 */
function CloseHandle(hObject) {
    Kernel32.PostMessage({
        nType: KERNEL32.CloseHandle,
        data: { hObject }
    });
    return true;
}
// consoleapi.h
/**
 *
 * @returns
 */
async function AllocConsole() {
    return false; // TODO: implement
}
/**
 *
 * @param hConsoleOutput
 * @param lpBuffer
 * @returns
 */
async function WriteConsole(hConsoleOutput, lpBuffer) {
    return WriteFile(hConsoleOutput, new TextEncoder().encode(lpBuffer), lpBuffer.length)
        .then((ret) => ret.retVal);
}
/**
 *
 * @param hConsoleInput
 * @param nNumberOfCharsToRead
 * @returns
 */
async function ReadConsole(hConsoleInput, nNumberOfCharsToRead) {
    const buffer = new Uint8Array(nNumberOfCharsToRead);
    const ret = await ReadFile(hConsoleInput, buffer, buffer.length);
    return new TextDecoder().decode(buffer.slice(0, ret.lpNumberOfBytesRead));
}
/**
 *
 * @returns
 */
async function GetConsoleTitle() {
    return "";
}
/**
 *
 * @param lpConsoleTitle
 * @returns
 */
async function SetConsoleTitle(lpConsoleTitle) {
    return false;
}
// debugapi.h
/**
 *
 * @param lpOutputString
 */
function OutputDebugString(lpOutputString) {
    console.debug(lpOutputString);
}
function MulDiv(nNumber, nNumerator, nDenominator) {
    return Math.floor(nNumber * nNumerator / nDenominator);
}
async function Kernel32Initialize() {
    Kernel32 = await ntdll.NtRegisterSubsystem(SUBSYS_KERNEL32, Kernel32_HandleMessage, 4096);
    K32Memory = new Uint32Array(Kernel32.memory);
}
const kernel32 = {
    file: "kernel32.js",
    type: "dll",
    subsystem: "console",
    arch: "js",
    entryPoint: "Kernel32Initialize",
    dependencies: ["ntdll.js"],
    name: "kernel32",
    version: [1, 0, 0, 0],
    rsrc: {}
};

exports.AllocConsole = AllocConsole;
exports.CREATE_ALWAYS = CREATE_ALWAYS;
exports.CREATE_NEW = CREATE_NEW;
exports.CloseHandle = CloseHandle;
exports.CreateDirectory = CreateDirectory;
exports.CreateFile = CreateFile;
exports.FILE_ATTRIBUTE_ARCHIVE = FILE_ATTRIBUTE_ARCHIVE;
exports.FILE_ATTRIBUTE_DEVICE = FILE_ATTRIBUTE_DEVICE;
exports.FILE_ATTRIBUTE_DIRECTORY = FILE_ATTRIBUTE_DIRECTORY;
exports.FILE_ATTRIBUTE_HIDDEN = FILE_ATTRIBUTE_HIDDEN;
exports.FILE_ATTRIBUTE_NORMAL = FILE_ATTRIBUTE_NORMAL;
exports.FILE_ATTRIBUTE_READONLY = FILE_ATTRIBUTE_READONLY;
exports.FILE_ATTRIBUTE_SYSTEM = FILE_ATTRIBUTE_SYSTEM;
exports.FILE_ATTRIBUTE_TEMPORARY = FILE_ATTRIBUTE_TEMPORARY;
exports.FILE_BEGIN = FILE_BEGIN;
exports.FILE_CURRENT = FILE_CURRENT;
exports.FILE_END = FILE_END;
exports.FILE_FLAG_DELETE_ON_CLOSE = FILE_FLAG_DELETE_ON_CLOSE;
exports.FILE_FLAG_NO_BUFFERING = FILE_FLAG_NO_BUFFERING;
exports.FILE_FLAG_OVERLAPPED = FILE_FLAG_OVERLAPPED;
exports.FILE_FLAG_RANDOM_ACCESS = FILE_FLAG_RANDOM_ACCESS;
exports.FILE_FLAG_WRITE_THROUGH = FILE_FLAG_WRITE_THROUGH;
exports.FILE_GENERIC_EXECUTE = FILE_GENERIC_EXECUTE;
exports.FILE_GENERIC_READ = FILE_GENERIC_READ;
exports.FILE_GENERIC_WRITE = FILE_GENERIC_WRITE;
exports.FILE_SHARE_DELETE = FILE_SHARE_DELETE;
exports.FILE_SHARE_READ = FILE_SHARE_READ;
exports.FILE_SHARE_VALID_FLAGS = FILE_SHARE_VALID_FLAGS;
exports.FILE_SHARE_WRITE = FILE_SHARE_WRITE;
exports.GENERIC_ALL = GENERIC_ALL;
exports.GENERIC_EXECUTE = GENERIC_EXECUTE;
exports.GENERIC_READ = GENERIC_READ;
exports.GENERIC_WRITE = GENERIC_WRITE;
exports.GetConsoleTitle = GetConsoleTitle;
exports.GetCurrentProcess = GetCurrentProcess;
exports.GetLastError = GetLastError;
exports.GetModuleHandle = GetModuleHandle;
exports.GetProcessId = GetProcessId;
exports.GetStdHandle = GetStdHandle;
exports.IDX_HMODULE = IDX_HMODULE;
exports.IDX_LAST_ERROR = IDX_LAST_ERROR;
exports.IDX_PID = IDX_PID;
exports.Kernel32Initialize = Kernel32Initialize;
exports.MulDiv = MulDiv;
exports.OPEN_ALWAYS = OPEN_ALWAYS;
exports.OPEN_EXISTING = OPEN_EXISTING;
exports.OutputDebugString = OutputDebugString;
exports.ReadConsole = ReadConsole;
exports.ReadFile = ReadFile;
exports.STD_ERROR_HANDLE = STD_ERROR_HANDLE;
exports.STD_INPUT_HANDLE = STD_INPUT_HANDLE;
exports.STD_OUTPUT_HANDLE = STD_OUTPUT_HANDLE;
exports.SetConsoleTitle = SetConsoleTitle;
exports.SetFilePointer = SetFilePointer;
exports.SetLastError = SetLastError;
exports.TRUNCATE_EXISTING = TRUNCATE_EXISTING;
exports.WriteConsole = WriteConsole;
exports.WriteFile = WriteFile;
exports.default = kernel32;
//# sourceMappingURL=kernel32.js.map
