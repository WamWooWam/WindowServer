(function (exports) {
    'use strict';

    const CALLBACK_MESSAGE_TYPE = 0x7FFFFFFF;

    const NTDLL = {
        ProcessCreate: 0x00000001,
        LoadSubsystem: 0x00000002,
        ProcessExit: 0x00000003,
        ProcessCrash: 0x00000004,
        LoadLibrary: 0x00000005,
    };

    const SUBSYS_NTDLL = "ntdll";

    /**
     * @module ntdll
     * @description NT Layer DLL
     * @see {@link https://docs.microsoft.com/en-us/windows/win32/api/winbase/}
     * @usermode
     */
    // all worker events should be handled by this subsystem
    const __addEventListener = globalThis.addEventListener;
    const __postMessage = globalThis.postMessage;
    class SubsystemClass {
        get memory() {
            return this.sharedMemory;
        }
        constructor(name, handler, sharedMemory = null) {
            this.callbackMap = new Map();
            this.callbackId = 0x4000;
            this.name = name;
            this.handler = handler;
            this.sharedMemory = sharedMemory;
            __addEventListener('message', (event) => this.HandleMessage(event.data));
        }
        async SendMessage(msg) {
            // console.debug(`${this.name}:client sending message %s:%d, %O`, this.name, msg.nType, msg);
            return new Promise((resolve, reject) => {
                var _a;
                const channel = this.RegisterCallback((msg) => {
                    if (msg.nType & 0x80000000) {
                        reject(msg.data);
                    }
                    else {
                        resolve(msg);
                    }
                });
                globalThis.postMessage({
                    lpSubsystem: this.name,
                    nType: msg.nType,
                    nChannel: (_a = msg.nReplyChannel) !== null && _a !== void 0 ? _a : channel,
                    nReplyChannel: channel,
                    data: msg.data
                });
            });
        }
        async PostMessage(msg) {
            // console.debug(`${this.name}:client sending message %s:%d, %O`, this.name, msg.nType, msg);
            __postMessage({
                lpSubsystem: this.name,
                nType: msg.nType,
                nChannel: msg.nChannel,
                nReplyChannel: msg.nReplyChannel,
                data: msg.data
            });
        }
        RegisterCallback(callback, persist = false) {
            const id = this.callbackId++;
            const handler = async (msg) => {
                if (!persist)
                    this.callbackMap.delete(id);
                return await callback(msg);
            };
            this.callbackMap.set(id, handler);
            return id;
        }
        GetCallback(id) {
            return this.callbackMap.get(id);
        }
        async HandleMessage(msg) {
            if (msg.lpSubsystem !== this.name)
                return;
            // console.log(`${this.name}:client recieved message %s:%d -> %d, %O`, msg.lpSubsystem, msg.nType, msg.nChannel, msg);
            const callback = msg.nChannel && this.callbackMap.get(msg.nChannel);
            if (callback) {
                let ret = await callback(msg);
                if (msg.nReplyChannel) {
                    await this.PostMessage({ nType: msg.nType, nChannel: msg.nReplyChannel, data: ret });
                }
            }
            else {
                return this.handler(msg);
            }
        }
    }
    const loadedModules = ["ntdll.js"];
    const loadedModuleExports = new Map();
    loadedModuleExports.set("ntdll", {
        NtRegisterSubsystem
    });
    const __oldRequire = globalThis.require;
    const NtRequire = (module) => {
        if (!loadedModuleExports.has(module)) {
            if (__oldRequire) {
                return __oldRequire(module);
            }
            else {
                throw new Error(`module ${module} not found`);
            }
        }
        return loadedModuleExports.get(module);
    };
    globalThis.require = NtRequire;
    __addEventListener('message', (event) => {
        // console.debug(`client recieved message %s:%d, %O`, event.data.lpSubsystem, event.data.nType, event.data);
    });
    __addEventListener('error', (event) => {
        var _a, _b;
        // console.error(event); // TODO: send error to parent
        Ntdll.SendMessage({
            nType: NTDLL.ProcessCrash,
            data: {
                uExitCode: 0xC0000144,
                error: (_b = (_a = event.error) !== null && _a !== void 0 ? _a : event.message) !== null && _b !== void 0 ? _b : event
            }
        });
    });
    __addEventListener('messageerror', (event) => {
        console.error(event); // TODO: send error to parent
    });
    __addEventListener('unhandledrejection', (event) => {
        Ntdll.SendMessage({
            nType: NTDLL.ProcessCrash,
            data: {
                uExitCode: 0xC0000409,
                error: event.reason
            }
        });
    });
    const Ntdll = new SubsystemClass(SUBSYS_NTDLL, NTDLL_HandleMessage);
    async function NtRegisterSubsystem(subsys, handler, cbSharedMemory = 0) {
        const retVal = await Ntdll.SendMessage({
            nType: NTDLL.LoadSubsystem,
            data: {
                lpSubsystem: subsys,
                cbSharedMemory
            }
        });
        return new SubsystemClass(subsys, handler, retVal.data.lpSharedMemory);
    }
    async function LdrInitializeThunk(pPC) {
        const exec = pPC.lpExecutable;
        for (const lpDependencies of exec.dependencies) {
            await LdrLoadDll(lpDependencies);
        }
        await BaseThreadInitThunk(pPC);
    }
    async function LdrSearchPath(lpLibFileName, pPC) {
        try {
            let libLibraryName = lpLibFileName.split('.')[0]; // kernel32.js -> kernel32
            if (loadedModules.includes(lpLibFileName)) {
                return loadedModuleExports.get(libLibraryName);
            }
            const retVal = await Ntdll.SendMessage({
                nType: NTDLL.LoadLibrary,
                data: {
                    lpLibFileName
                }
            });
            const module = await fetch(retVal.data.lpszLibFile);
            const exec = await module.text();
            const func = new Function("exports", exec);
            const exports = {};
            func(exports); // TODO: use a sandbox
            console.log(`LdrSearchPath:${lpLibFileName} -> ${retVal.data.lpszLibFile}`);
            console.log(exports);
            loadedModules.push(lpLibFileName);
            loadedModuleExports.set(libLibraryName, exports);
            return exports;
        }
        catch (e) {
            console.error(`LdrSearchPath:${lpLibFileName} -> ${e}`);
            debugger;
            throw e;
        }
    }
    async function LdrLoadDll(lpLibFileName, pPC) {
        if (loadedModules.includes(lpLibFileName))
            return;
        console.log(`LdrLoadDll:${lpLibFileName}...`);
        // TODO: search for dll in search path
        const module = await LdrSearchPath(lpLibFileName);
        if (!(module === null || module === void 0 ? void 0 : module.default)) {
            throw new Error(`invalid module ${lpLibFileName}`);
        }
        loadedModules.push(lpLibFileName);
        const exec = module.default;
        if (exec.type !== "dll") {
            throw new Error(`invalid module ${lpLibFileName}`);
        }
        for (const lpDependency of exec.dependencies) {
            await LdrLoadDll(lpDependency);
        }
        console.log(`LdrLoadDll:${lpLibFileName} -> ${exec.entryPoint}`);
        let retVal = 0;
        if (exec.entryPoint) {
            if (typeof exec.entryPoint === "string" && module[exec.entryPoint]) {
                retVal = await module[exec.entryPoint]();
            }
            else if (typeof exec.entryPoint === "function") {
                retVal = await exec.entryPoint();
            }
            else {
                retVal = 0x800700C1;
            }
        }
        return retVal !== null && retVal !== void 0 ? retVal : 0;
    }
    async function BaseThreadInitThunk(pPC) {
        const exec = pPC.lpExecutable;
        const module = await LdrSearchPath(exec.file);
        let retVal = 0;
        if (exec.entryPoint) {
            if (typeof exec.entryPoint === "string" && module[exec.entryPoint]) {
                retVal = await module[exec.entryPoint]();
            }
            else if (typeof exec.entryPoint === "function") {
                retVal = await exec.entryPoint();
            }
            else {
                retVal = 0x800700C1;
            }
        }
        await Ntdll.SendMessage({
            nType: NTDLL.ProcessExit,
            data: {
                uExitCode: retVal !== null && retVal !== void 0 ? retVal : 0
            }
        });
    }
    function NTDLL_HandleMessage(msg) {
        switch (msg.nType) {
            case NTDLL.ProcessCreate: // load executable
                LdrInitializeThunk(msg.data);
                break;
        }
    }
    const ntdll = {
        file: "ntdll.js",
        type: "dll",
        subsystem: "console",
        arch: "js",
        entryPoint: null,
        dependencies: [],
        name: "ntdll",
        version: [1, 0, 0, 0],
        rsrc: {}
    };

    exports.CALLBACK_MESSAGE_TYPE = CALLBACK_MESSAGE_TYPE;
    exports.NtRegisterSubsystem = NtRegisterSubsystem;
    exports.default = ntdll;

    Object.defineProperty(exports, '__esModule', { value: true });

    return exports;

})({});
//# sourceMappingURL=ntdll.js.map
