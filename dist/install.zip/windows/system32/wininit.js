'use strict';

var user32 = require('user32');

/*
* Stub wininit, which is the first process created by the kernel.
* Currently just creates a desktop and waits for messages.
*/
async function main() {
    const window = await user32.FindWindow(0x8001, null);
    if (window)
        return;
    await user32.CreateDesktop("PrimaryDesktop", '', null, 0, 0, null);
    let msg = {};
    while (await user32.GetMessage(msg, 0, 0, 0)) {
        await user32.TranslateMessage(msg);
        await user32.DispatchMessage(msg);
    }
    return 0;
}

exports.main = main;
//# sourceMappingURL=wininit.js.map
